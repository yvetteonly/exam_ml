import gradio as gr
def predict_banknote(variance, skewness, curtosis, entropy):
    # Create an array from input
    input_data = [[variance, skewness, curtosis, entropy]]
    
    # Make prediction
    prediction = model.predict(input_data)
    
    # Return result
    return "Real" if prediction[0] == 1 else "Fake"
interface = gr.Interface(
    fn=predict_banknote,
    inputs=[gr.Number(label="Variance"), gr.Number(label="Skewness"),
            gr.Number(label="Curtosis"), gr.Number(label="Entropy")],
    outputs="text",
    title="Banknote Authentication",
    description="Enter banknote details to check if it's real or fake."
)
interface.launch(share=True)
